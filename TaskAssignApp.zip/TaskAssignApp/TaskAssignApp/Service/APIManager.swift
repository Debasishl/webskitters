//
//  APIManager.swift
//  TaskAssignApp
//
//  Created by Debasish Mondal on 08/01/21.
//  Copyright © 2021 DevsCode. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON


class APIManager {

    class private func _dynamicHeader() -> HTTPHeaders {
        
        let headers: HTTPHeaders = [
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer 739|c0DxqQa9nURCa2OSMMgxAdyEMdLre0JCscuXpTYz"
        ]
        return headers
    }
    
    
    class func getWebService( success: @escaping ( _ data: Data) -> Void,  failure: @escaping ( _ code: Int, _ errors: [String]) -> Void )
       {
           AF.request("http://planningpro.dedicateddevelopers.us/api/role/planning/0", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: _dynamicHeader()).validate().responseJSON { (result) in
               print(result.error)
               if Helper.helper.checkNetworkRecheablity(){
                   if result.error != nil {
                       failure(result.response!.statusCode, (result.error?.acceptableContentTypes)!)
                   } else {
                       success(result.data!)
                   }
               }else{
                   print("No internet connection")
               }
           }
       }
}
    
    
    
