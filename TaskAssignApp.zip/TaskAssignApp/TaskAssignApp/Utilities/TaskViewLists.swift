//
//  TaskViewLists.swift
//  TaskAssignApp
//
//  Created by Debasish Mondal on 08/01/21.
//  Copyright © 2021 DevsCode. All rights reserved.
//

class TaskViewLists
{
    //MARK:  Load Nodes From Initial Data
    
    static func LoadInitialNodes(dataList: [TaskListViewData]) -> [TaskListViewNode]
    {
        var nodes: [TaskListViewNode] = []
        
        for data in dataList where data.level == 0
        {
             print("\(data.name)")
            
            let node: TaskListViewNode = TaskListViewNode()
            node.nodeLevel = data.level
            node.nodeObject = data.name as AnyObject
            node.nodeParentId = data.parentId as AnyObject
            node.isExpanded = GlobalVariables.FALSE
            let newLevel = data.level + 1
            node.nodeChildren = LoadChildrenNodes(dataList: dataList, level: newLevel, parentId: data.id)
            
            if (node.nodeChildren?.count == 0)
            {
                node.nodeChildren = nil
            }
            
            nodes.append(node)
         
        }
        
        return nodes
    }
    
    //MARK:  Recursive Method to Create the Children/Grandchildren....  node arrays
    
    static func LoadChildrenNodes(dataList: [TaskListViewData], level: Int, parentId: String) -> [TaskListViewNode]
    {
        var nodes: [TaskListViewNode] = []
        
        for data in dataList where data.level == level && data.parentId == parentId
        {
            print("\(data.name)")
            
            let node: TaskListViewNode = TaskListViewNode()
            node.nodeLevel = data.level
            node.nodeObject = data.name as AnyObject
            node.isExpanded = GlobalVariables.FALSE
            let newLevel = level + 1
            node.nodeChildren = LoadChildrenNodes(dataList: dataList, level: newLevel, parentId: data.id)
            
            if (node.nodeChildren?.count == 0)
            {
                node.nodeChildren = nil
            }
            
            nodes.append(node)
            
        }
        
        return nodes
    }
    
    
}
