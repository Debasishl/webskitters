//
//  GlobalVariables.swift
//  TaskAssignApp 
//
//  Created by Debasish Mondal on 08/01/21.
//  Copyright © 2021 DevsCode. All rights reserved.
//

class GlobalVariables
{
    static let TRUE = "true"
    static let FALSE = "false"
}
