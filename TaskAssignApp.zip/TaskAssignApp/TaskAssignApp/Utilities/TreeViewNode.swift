//
//  TaskListViewNode.swift
//  TaskAssignApp
//
//  Created by Debasish Mondal on 08/01/21.
//  Copyright © 2021 DevsCode. All rights reserved.
//


class TaskListViewNode
{
    
    var nodeLevel: Int?
    var isExpanded: String?
    var nodeObject: AnyObject?
    var nodeParentId: AnyObject?
    var nodeChildren: [AnyObject]?
    
  
}
