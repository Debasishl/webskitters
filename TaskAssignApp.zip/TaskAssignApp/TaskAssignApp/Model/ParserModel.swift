//
//  ParserModel.swift
//  TaskAssignApp
//
//  Created by Debasish Mondal on 08/01/21.
//  Copyright © 2021 DevsCode. All rights reserved.
//

import Foundation

struct ParserModel : Codable {
    let status : Bool?
    let code : Int?
    let data : [MainData]?
    let message : String?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case code = "code"
        case data = "data"
        case message = "message"
    }

}
struct MainData : Codable {
    let id : Int?
    let role_name : String?
    let role_type : Int?
    let company : String?
    let colour : String?
    let order : String?
    let user_id : Int?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let planning : Planning?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case role_name = "role_name"
        case role_type = "role_type"
        case company = "company"
        case colour = "colour"
        case order = "order"
        case user_id = "user_id"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case planning = "planning"
    }
}
struct Planning : Codable {
    let id : Int?
    let mission : String?
    let vision : String?
    let type : Int?
    let client_role_id : Int?
    let year : String?
    let quarter : String?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let objective : [Objective]?
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case mission = "mission"
        case vision = "vision"
        case type = "type"
        case client_role_id = "client_role_id"
        case year = "year"
        case quarter = "quarter"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case objective
    }


}
struct Objective : Codable {
    
    let id : Int?
    let content_obj : String?
    let score : String?
    let project_id : String?
    let planning_id : Int?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let key_result : [Key_result]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case content_obj = "content_obj"
        case score = "score"
        case project_id = "project_id"
        case planning_id = "planning_id"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case key_result = "key_result"

    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        content_obj = try values.decodeIfPresent(String.self, forKey: .content_obj)
        score = try values.decodeIfPresent(String.self, forKey: .score)
        project_id = try values.decodeIfPresent(String.self, forKey: .project_id)
        planning_id = try values.decodeIfPresent(Int.self, forKey: .planning_id)
        created_at = try values.decodeIfPresent(String.self, forKey: .created_at)
        updated_at = try values.decodeIfPresent(String.self, forKey: .updated_at)
        deleted_at = try values.decodeIfPresent(String.self, forKey: .deleted_at)
        key_result = try values.decodeIfPresent([Key_result].self, forKey: .key_result)
    }

}
struct Key_result : Codable {
    
    let id : Int?
    let key_result : String?
    let metrics : String?
    let objective_id : Int?
    let created_at : String?
    let updated_at : String?
    let deleted_at : String?
    let type : Int?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case key_result = "key_result"
        case metrics = "metrics"
        case objective_id = "objective_id"
        case created_at = "created_at"
        case updated_at = "updated_at"
        case deleted_at = "deleted_at"
        case type = "type"
    }

}
