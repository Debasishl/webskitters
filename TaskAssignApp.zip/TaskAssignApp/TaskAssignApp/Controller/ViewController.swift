//
//  ViewController.swift
//  TaskAssignApp
//
//  Created by Debasish Mondal on 08/01/21.
//  Copyright © 2021 DevsCode. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
  
   private var parser = [ParserModel]()
    @IBOutlet weak var treeTableView: UITableView!
    var displayArray = [TaskListViewNode]()
    var indentation: Int = 0
    var nodes: [TaskListViewNode] = []
    var dataAssign: [TaskListViewData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
         setUpInitialTask()
    }
    func setUpInitialTask(){
        APIManager.getWebService(success: success(_:), failure: failure(status:errors:))
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.ExpandCollapseNode(notification:)), name: NSNotification.Name(rawValue: "TreeNodeButtonClicked"), object: nil)
    }

    func success(_ data: Data)
      {
        print(data)
          do {
           let jsonDecoder = JSONDecoder()
            do {
                var result = try jsonDecoder.decode(ParserModel.self, from: data)
                 var myData: [TaskListViewData] = []
                if (result.data!.count > 0 ){
                for i in 0...result.data!.count - 1 {
                    let rolePlanningId = result.data![i].planning?.id ?? 0
                    myData.append(TaskListViewData(level: 0, name: (result.data![i].role_name ?? ""), id: "\(rolePlanningId)", parentId: "-1")!)
                    let objectiveTotalIndex = result.data![i].planning?.objective?.count
                    if (objectiveTotalIndex! > 0 ){
                    for j in  0...objectiveTotalIndex! - 1 {
                        let objectivePlnningId = result.data![i].planning?.objective![j].planning_id ?? 0
                        let objectiveId =  result.data![i].planning?.objective![j].id ?? 0
                        myData.append(TaskListViewData(level: 1, name: (result.data![i].planning?.objective![j].content_obj ?? ""), id: "\(objectiveId)", parentId: "\(objectivePlnningId)")!)
                        let keyResultsCount = result.data![i].planning?.objective?[j].key_result?.count
                        if (keyResultsCount! > 0 ){
                        for k in 0...keyResultsCount! - 1{
                            let keyObjectId = result.data![i].planning?.objective?[j].key_result?[k].objective_id ?? 0
                            let keyId = NSUUID().uuidString
                           myData.append(TaskListViewData(level: 2, name: (result.data![i].planning?.objective?[j].key_result?[k].key_result ?? ""), id: "\(keyId)", parentId:"\(keyObjectId)")!)
                        }
                        }

                    }
                }
                }
                    dataAssign = myData
            }
                      nodes = TaskViewLists.LoadInitialNodes(dataList: dataAssign   )
                        self.LoadDisplayArray()
                        self.treeTableView.reloadData()
               } catch {
                   print(error.localizedDescription)
               }
          } catch {
              print("Something went wrong")
          }
      }
      func failure( status: Int, errors: [String])
      {
          print("Something went wrong")
      }
    @objc func ExpandCollapseNode(notification: NSNotification)
    {
        self.LoadDisplayArray()
        self.treeTableView.reloadData()
    }
    
    func LoadDisplayArray()
    {
        self.displayArray = [TaskListViewNode]()
        for node: TaskListViewNode in nodes
        {
            self.displayArray.append(node)
            if (node.isExpanded == GlobalVariables.TRUE)
            {
                self.AddChildrenArray(childrenArray: node.nodeChildren as! [TaskListViewNode])
            }
        }
    }
    func AddChildrenArray(childrenArray: [TaskListViewNode])
    {
        for node: TaskListViewNode in childrenArray
        {
            self.displayArray.append(node)
            if (node.isExpanded == GlobalVariables.TRUE )
            {
                if (node.nodeChildren != nil)
                {
                    self.AddChildrenArray(childrenArray: node.nodeChildren as! [TaskListViewNode])
                }
            }
        }
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
             return displayArray.count;
          }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let node: TaskListViewNode = self.displayArray[indexPath.row]
                  let cell  = (self.treeTableView.dequeueReusableCell(withIdentifier: "TaskListViewCell") as! TaskListViewCell)
                  cell.treeNode = node
                  cell.treeLabel.text = node.nodeObject as! String?
                  let parntId =  node.nodeParentId as! String?
                  if (node.isExpanded == GlobalVariables.FALSE)
                  {
                      cell.setTheButtonBackgroundImage(backgroundImage: UIImage(named: "green-circle")!)
                       if parntId == "-1" {
                           cell.underlineView.isHidden = false
                       }
                       else {
                           cell.underlineView.isHidden = true
                       }
                  }
                  else
                  {
                      cell.setTheButtonBackgroundImage(backgroundImage: UIImage(named: "blue-circle")!)
                      cell.underlineView.isHidden = true
                  }
                  cell.setNeedsDisplay()
                  return cell
      }
    
}

